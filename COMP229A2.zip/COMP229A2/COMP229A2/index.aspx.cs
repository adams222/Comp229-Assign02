﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace COMP229A2
{
    public partial class index : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Request.QueryString["ac"] == "landingpage")
            {
                landingpage.Visible = true;
                surveypage.Visible = false;
                thankyoupage.Visible = false;
            }

            if (Request.QueryString["ac"] == "surveypage")
            {
                surveypage.Visible = true;
                landingpage.Visible = false;
                thankyoupage.Visible = false;
            }

            if (Request.QueryString["ac"] == "thankyoupage")
            {
                thankyoupage.Visible = true;
                surveypage.Visible = false;
                landingpage.Visible = false;
            }

            

        }

        protected void btnsubmit_Click(object sender, EventArgs e)
        {
            if (Page.IsValid)
            {
                surveypage.Visible = false;
                landingpage.Visible = false;

                name_l.Text = "Your name is :" + name.Text;
                gender_l.Text = "You are a " + gender.Text;
                recommend_l.Text = "Will you recommend Taka shoes to others?:" + ddl1.Text;

                thankyoupage.Visible = true;

            }
        }
    }
}